# import raillabel
import json
import cv2
import os
import shutil
import random
import numpy as np

dirt_yaml = {
            'person': 0,        'bicycle': 1,           'road_vehicle': 2,      'motorcycle': 3,
            'crowd': 4,         'group_of_bicycles': 5, 'train': 6,             'wagons': 7,
            'animal': 8,        'group_of_animals': 9,  'wheelchair': 10,       'drag_shoe': 11,
            'track': 12,        'transition': 13,       'switch': 14,           'catenary_pole': 15,
            'signal_pole': 16,  'signal': 17,           'signal_bridge': 18,    'buffer_stop': 19,
            'flame': 20,        'smoke': 21
}

# 定义要遍历的文件夹列表
rgb_folder_list = ["rgb_center", "rgb_left", "rgb_right",
               "rgb_highres_center", "rgb_highres_left", "rgb_highres_right"]

home_path = os.getcwd()                           # /home/be/Desktop/Train_Image_Dataset  主目录
print(home_path)
yolo_path = '/home/sys120/ty/project/ultralytics-main11/ultralytics/models/yolo/detect/yolo_data/'                       # yolo 数据集路径
yolo_image_path = yolo_path + 'image/'
yolo_image_train_path = yolo_image_path + 'train/'
yolo_image_valid_path = yolo_image_path + 'valid/'
yolo_label_path = yolo_path + 'label/'
yolo_label_train_path = yolo_label_path + 'train/'
yolo_label_valid_path = yolo_label_path + 'valid/'
train_ratio = 0.8                                   # 分配比例
valid_ratio = 0.2
# 遍历所有子文件夹里面的 6 个 rgb 图像文件夹，将每个文件夹里面的图像路径按照 8：2 随机分配到数据集的 train 和 valid
train_paths = []
valid_paths = []

def make_dirs():
    if os.path.exists(yolo_path):
        print("文件夹已存在！")
        shutil.rmtree(yolo_path)
    os.mkdir(yolo_path)
    os.makedirs(yolo_image_path)
    os.makedirs(yolo_image_train_path)
    os.makedirs(yolo_image_valid_path)
    os.makedirs(yolo_label_path)
    os.makedirs(yolo_label_train_path)
    os.makedirs(yolo_label_valid_path)

# 将文件夹里面的所有子文件的所有图片进行存储
def random_shuffle():
    for sub_folder in os.listdir(home_path):
        sub_folder_path = os.path.join(home_path, sub_folder)
        for folder in rgb_folder_list:
            sub_sub_folder_path = os.path.join(sub_folder_path, folder)
            if not os.path.exists(sub_sub_folder_path):
                continue
            current_folder_images = []
            for file_name in os.listdir(sub_sub_folder_path):
                file_path = os.path.join(sub_sub_folder_path, file_name)
                current_folder_images.append(file_path)
            random.shuffle(current_folder_images)
            split_index = int(4 * len(current_folder_images) / 5)
            train_paths.extend(current_folder_images[:split_index])
            valid_paths.extend(current_folder_images[split_index:])
    print(len(train_paths), train_paths)
    print(len(valid_paths), valid_paths)

def transfer():
    n = 0  # 统计现在向数据集移动了多少个图像
    # 将标签文件的内容转换成需要用到的 txt
    for folder_name in os.listdir(home_path):
        if not os.path.isdir(folder_name):          # 先跳过 dataset.py
            continue
        # 首先筛掉不是数据的文件夹
        sub_folder_path = os.path.join(home_path, folder_name)
        # 检查子文件夹中是否存在 JSON 文件
        json_found = False
        json_file = ''
        for item in os.listdir(sub_folder_path):
            if item.endswith('.json'):
                json_found = True
                json_file = item
                break
        if json_found:
            print("当前子文件夹中存在 JSON 文件。")
        else:
            continue

        sub_json_path = os.path.join(sub_folder_path, json_file)
        print("当前数据文件夹:             ", folder_name)
        print("当前文件夹路径:             ", sub_folder_path)
        print("当前文件夹标签文件路径:      ", sub_json_path)
        # 读取文件夹对应的 json 文件
        with open(sub_json_path, 'r') as data_file:
            scene = json.load(data_file)
            frames = scene['openlabel']['frames']
            # 遍历每一帧 frame
            for frame, frame_value in frames.items():
                print('current frame ================================================================================'+\
                      '======================================================================================: ', frame)
                for properties_or_objects, _value in frame_value.items():
                    print('properties_or_objects==============================================:', properties_or_objects)
                    # 获取图片和对应的时间戳
                    if properties_or_objects == 'frame_properties':
                        streams_value = _value['streams']
                        for key_folder, image_path in streams_value.items():
                            original_image_path = sub_folder_path + image_path['uri']
                            # 排除不是 rgb 的图像
                            if 'ir' in image_path['uri'] or 'lidar' in image_path['uri'] or 'radar' in image_path['uri']:
                                continue
                            # 确定图像是否存在
                            if not os.path.exists(original_image_path):
                                print('error')
                                break
                            # 判断图像属于 train 还是 valid
                            # 在传输图像的时候顺便进行变亮的增强处理,扩充一倍的数据集
                            if judge_train_valid(original_image_path) == 'train':
                                # 读取当前路径下面的图片然后复制到数据集的路径下面
                                shutil.copy(original_image_path, yolo_image_train_path)
                                old_image_name = yolo_image_train_path + image_path['uri'].split("/")[-1]
                                new_image_name = yolo_image_train_path + folder_name + '_' + key_folder + '_' + image_path['uri'].split("/")[-1].split("_")[0] + '.png'
                                os.rename(old_image_name, new_image_name)
                                # # 图像增强并另存为 _2 版本
                                # pre_image = cv2.imread(new_image_name)
                                # done_image = brighter(pre_image)
                                # cv2.imwrite(yolo_image_train_path + folder_name + '_' + key_folder + '_' + image_path['uri'].split("/")[-1].split("_")[0] + '_2' + '.png', done_image)
                            elif judge_train_valid(original_image_path) == 'valid':
                                shutil.copy(original_image_path, yolo_image_valid_path)
                                old_image_name = yolo_image_valid_path + image_path['uri'].split("/")[-1]
                                new_image_name = yolo_image_valid_path + folder_name + '_' + key_folder + '_' + image_path['uri'].split("/")[-1].split("_")[0] + '.png'
                                os.rename(old_image_name, new_image_name)
                                # # 图像增强并另存为 _2 版本
                                # pre_image = cv2.imread(new_image_name)
                                # done_image = brighter(pre_image)
                                # cv2.imwrite(yolo_image_valid_path + folder_name + '_' + key_folder + '_' + image_path['uri'].split("/")[-1].split("_")[0] + '_1' + '.png', done_image)
                            n += 1
                            print(n)

                    # 获取标签文件 txt 的信息
                    if properties_or_objects == 'objects':
                        for key_object_data, value_object_data in _value.items():
                            for key, value in value_object_data.items():
                                for key_bbox, value_bbox in value.items():
                                    # 不属于 bbox 的数据，例如 poly2d 直接跳过
                                    if key_bbox == 'bbox':
                                        for value_bbox_i in value_bbox:
                                            # 开始判断单个 bbox 的数据对应的种类以及所属的图片的文件夹
                                            # 获取图片的尺寸并计算框的距离比例
                                            if value_bbox_i['coordinate_system'] in rgb_folder_list:
                                                # 获取 bbox 对应目标物体的种类
                                                class_name = value_bbox_i['name'].split('__')[-1]
                                                class_index = dirt_yaml[class_name]
                                                print(value_bbox_i['name'], '       ', class_name, ':   ', class_index)
                                                image_h = 0
                                                image_w = 0
                                                frame_current_path = ''
                                                # 标签文件命名（文件夹_摄像机文件夹_第几帧）
                                                formatted_frame = '{:0>3}'.format(frame)
                                                new_txt_name = folder_name + '_' + value_bbox_i[
                                                        'coordinate_system'] + '_' + formatted_frame + '.txt'
                                                find_image_ = formatted_frame + '_'
                                                # 此处循环只为找到获得 bbox 对应图片并获得 高宽 尺寸数据，然后计算出 bbox 的数据
                                                bbox_folder = os.path.join(sub_folder_path, value_bbox_i['coordinate_system'])
                                                for image_name in os.listdir(bbox_folder):
                                                    if find_image_ in image_name:
                                                        frame_current_path = os.path.join(bbox_folder, image_name)
                                                        frame_current_file = cv2.imread(frame_current_path)
                                                        image_h, image_w, c = frame_current_file.shape          # 这个没有问题
                                                txt_bbox = to_yolo(value_bbox_i['val'], image_h, image_w)
                                                txt_str = str(class_index) + ' ' + str(
                                                                ' '.join(str(element) for element in txt_bbox)) + '\n'
                                                print(frame_current_path)
                                                # 判断标签文件是 train 还是 valid
                                                if judge_train_valid(frame_current_path) == 'train':
                                                    txt_path = os.path.join(yolo_label_train_path,
                                                                            new_txt_name)
                                                    with open(txt_path, 'a') as txt_file:
                                                        txt_file.write(txt_str)
                                                        txt_file.close()
                                                elif judge_train_valid(frame_current_path) == 'valid':
                                                    txt_path = os.path.join(yolo_label_valid_path,
                                                                            new_txt_name)
                                                    with open(txt_path, 'a') as txt_file:
                                                        txt_file.write(txt_str)
                                                        txt_file.close()

                                                print(value_bbox_i['name'], ' ', 'h: ', image_h, 'w: ', image_w)
                                                print(txt_str)
                                                print(n)
                                                print()
                                            else:
                                                continue


def to_yolo(bbox, image_h, image_w):
    # 四个数据分别为： 中心点_x、中心点_y、检测框_宽、检测框_高
    return [bbox[0] / image_w, bbox[1] / image_h, bbox[2] / image_w, bbox[3] / image_h]

def judge_train_valid(path):
    if path in train_paths:
        return 'train'
    if path in valid_paths:
        return 'valid'


# 亮度
# def brighter(image, percetage=1.3):
#     image_copy = image.copy()
#     w = image.shape[1]
#     h = image.shape[0]
#     # get brighter
#     for xi in range(0, w):
#         for xj in range(0, h):
#             image_copy[xj, xi, 0] = np.clip(int(image[xj, xi, 0] * percetage), a_max=255, a_min=0)
#             image_copy[xj, xi, 1] = np.clip(int(image[xj, xi, 1] * percetage), a_max=255, a_min=0)
#             image_copy[xj, xi, 2] = np.clip(int(image[xj, xi, 2] * percetage), a_max=255, a_min=0)
#     return image_copy

if __name__ == '__main__':
    make_dirs()
    random_shuffle()
    transfer()

